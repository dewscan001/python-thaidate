from datetime import date
import re

class thaidate:
    
    def __init__(self, value = None, Buddhist = False):
        self.value = value
        self.Buddhist = Buddhist
        self.thai_month = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม']
        self.value_date = ''
        
        self.check_value()
        
    def check_value(self):
        if self.value in (None, ''):
            self.value = date.today()
        
        if isinstance(self.value, date):
            self.value_date = self.value.strftime('%d %m %Y').split()
        else:
            self.check_str_date()
            
    def check_str_date(self):
        try:
            if ' ' in self.value:
                self.value_date = self.value.split()
            elif '/' in self.value:
                self.value_date = self.value.split('/')
            elif '-' in self.value:
                self.value_date = self.value.split('-')
            else:
                raise Exception('คุณต้องกำหนดข้อมูลให้อยู่รูปแบบ yyyy mm dd, yyyy-mm-dd, yyyy/mm/dd เท่านั้น')
                
        except Exception as error:
            print('Caught this error: ' + repr(error))
            
    def show(self):
        if self.value_date[2] < self.value_date[0]:
            self.value_date.reverse()
        if self.Buddhist == False:
            self.value_date[2] = int(self.value_date[2])+543
        try:
            self.value_date = 'วันที่ ' + str(int(self.value_date[0])) + ' เดือน ' + self.thai_month[int(self.value_date[1]) - 1] + ' พ.ศ. ' + str(int(self.value_date[2]))
            return str(self.value_date)
            raise Exception('คุณต้องกำหนดข้อมูลให้อยู่รูปแบบ yyyy mm dd, yyyy-mm-dd, yyyy/mm/dd เท่านั้น')
        except Exception as error:
            print('Caught this error: ' + repr(error))
        
    def __repr__(self):
        return self.show()
    
    def __str__(self):
        return self.show()