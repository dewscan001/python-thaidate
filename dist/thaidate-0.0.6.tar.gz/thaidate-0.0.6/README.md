# Project Thaidate 

## Status : Alpha-0.0.6

## Usage

```
from thaidate import thaidate


    thaidate('วัน เดือน ปี', True/False)
    ex1: 
        x = thaidate('1 2 5', True) ใช้เมื่อปี คือ พ.ศ.
        # วันที่ 1 เดือน กุมภาพันธ์ พ.ศ. 5
        
    ex2: 
        x = thaidate('1 2 5', False) ใช้เมื่อปี คือ ค.ศ.
        x = thaidate('1 2 5')
        # วันที่ 1 เดือน กุมภาพันธ์ พ.ศ. 548
        
    ex3:
        x = thaidate()
        # วันที่ปัจจุบัน
        
x = thaidate()
print(x)    

```